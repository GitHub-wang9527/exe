## Windows 下给文件夹添加注释

#####如何使用程序
> - 如何运行 exe 版本
    > + 下载 ./release 文件夹下的文件夹或压缩包
    > + 打开文件夹，运行 remark.exe

> - 如何运行 python 版本
    > + 适配版本： python3.4 
    > + python remark.py

> - 操作
    > - remark 文件夹路径 "文件夹备注内容"
    > - remark
    > 运行后按照提示操作

---

#####注意
该脚本会修改文件夹下隐藏的 Desktop.ini 文件，并为文件夹修饰 System 属性，请注意。