FileCryptor

Fuction:
FileCryptor is a light weighted file encryptor/decryptor. It can be installed in a folder and all the files in the folder and sub-folders are managed by the application.

Installation:
1. Create a folder anywhere, including hard disk or USB disk.
2. Copy the executable file FileCryptor.exe into the folder.
3. Run FileCryptor.exe, input a password (which can be changed later), and remember the password firmly.

NOTE:
1. Do NOT rename the executable file name.
2. Do NOT copy the INI file when installing. The INI file will be created when you run the application first time.
3. Make a copy of the INI file, and store it in a safe place. If the INI file is lost, all the encrypted files can never be decrypted.
4. Do NOT install the application in the root folder (eg. c:\) of the system disk. Or improper operation may destroy the system.
5. Do NOT embed the encryption system into another, which makes the system complicated, though it works.

Usage:
1. To encrypt/decrypt files, select files in the file list pane, and click "Encrypt" or "Decrypt" button in the tool bar.
2. Click the "Exit" button to exit the application.
3. Select the files and click "Shred" button to shred the files. Please note the shredded files can NEVER be recovered by any tools. Be careful to use the function.
4. Click "Option > Mode > Simple" menu to switch to simple mode. In the simple mode, you can drag files in Explorer and drop the files into the baskets named "Encrypt", "Decrypt", and "Shred". To switch back to the normal mode, simply double click on any baskets.
5. To encrypt/decrypt all the files in the folder and sub-folders, use menu "Operate > Encrypt all" or "Operate > Decrypt all".
6. To stop the task immediately, double click the progress bar, or click "Operate > Interrupt".
7. To change the password, use menu "File > New password".
8. To change the language of the user interface, use menu "Option > Language > English".
9. Do not forget to click "Help > Tutorial" to get help.

Thanks and enjoy!
Yanmiao Liu
yanmiao_liu(at)yahoo.com
8/16/2018